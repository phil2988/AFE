import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-credit-card-details-page',
  templateUrl: './credit-card-details-page.component.html',
  styleUrls: ['./credit-card-details-page.component.css']
})
export class CreditCardDetailsPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
