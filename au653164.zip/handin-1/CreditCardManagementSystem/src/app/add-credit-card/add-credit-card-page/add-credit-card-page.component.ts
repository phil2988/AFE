import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-credit-card-page',
  templateUrl: './add-credit-card-page.component.html',
  styleUrls: ['./add-credit-card-page.component.css']
})
export class AddCreditCardPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
