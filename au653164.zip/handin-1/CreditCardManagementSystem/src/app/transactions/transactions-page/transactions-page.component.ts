import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transactions-page',
  templateUrl: './transactions-page.component.html',
  styleUrls: ['./transactions-page.component.css']
})
export class TransactionsPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
