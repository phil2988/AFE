import { MsToDatePipe } from './ms-to-date.pipe';

describe('MsToDatePipe', () => {
  it('create an instance', () => {
    const pipe = new MsToDatePipe();
    expect(pipe).toBeTruthy();
  });
});
